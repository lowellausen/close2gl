//     Universidade Federal do Rio Grande do Sul
//             Instituto de Inform�tica
//       Departamento de Inform�tica Aplicada
//
// INF01007     Computa��o Gr�fica 2018/1
//      Prof. Manuel Menezes de Oliveira Neto
//
//                    Assingment #1
//AAAAA

#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/mat4x4.hpp>
#include <glm/vec4.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/mat4x4.hpp>
#include <glm/vec4.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "my_obj_loader.cpp"
#include "matrix.cpp"

#include "../imgui/imgui.h"
#include "imgui_impl_glfw_gl3.h"


void LoadShadersFromFiles(); // Carrega os shaders de v�rtice e fragmento, criando um programa de GPU
GLuint LoadShader_Vertex(const char* filename);   // Carrega um vertex shader
GLuint LoadShader_Fragment(const char* filename); // Carrega um fragment shader
void LoadShader(const char* filename, GLuint shader_id); // Fun��o utilizada pelas duas acima
GLuint CreateGpuProgram(GLuint vertex_shader_id, GLuint fragment_shader_id); // Cria um programa de GPU

void FramebufferSizeCallback(GLFWwindow* window, int width, int height);
void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mode);
void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void CursorPosCallback(GLFWwindow* window, double xpos, double ypos);
void ScrollCallback(GLFWwindow* window, double xoffset, double yoffset);

float g_ScreenRatio = 1.0f;

float g_AngleX = 0.0f;
float g_AngleY = 0.0f;
float g_AngleZ = 0.0f;

bool g_LeftMouseButtonPressed = false;
bool g_RightMouseButtonPressed = false;
bool g_MiddleMouseButtonPressed = false;


float g_CameraTheta = 0.0f; // �ngulo no plano ZX em rela��o ao eixo Z
float g_CameraPhi = 0.0f;   // �ngulo em rela��o ao eixo Y
float g_CameraDistance; // Dist�ncia da c�mera para a origem


GLuint vertex_shader_open_id;
GLuint fragment_shader_open_id;
GLuint vertex_shader_close_id;
GLuint fragment_shader_close_id;
GLuint program_close_id = 0;
GLuint program_open_id = 0;
GLint model_uniform;
GLint view_uniform;
GLint projection_uniform;
GLint model_color_uniform_open;
GLint model_color_uniform_close;


GLint frag_type_uniform;
GLuint nonef_index;
GLuint phongf_index;
GLuint* fragShades[] = {&nonef_index, &phongf_index};


GLint vertex_type_uniform;
GLuint no_shade_index;
GLuint gourAD_shade_index;
GLuint gourADS_shade_index;
GLuint phong_shade_index;
GLuint* vertShades[] = {&no_shade_index, &gourAD_shade_index, &gourADS_shade_index, &phong_shade_index };




glm::vec3 initial_cam_pos;
glm::vec3 camera_position_c ;
glm::vec3 camera_lookat_l    ;
glm::vec3 camera_view_vector ;
glm::vec3 obj_center;
glm::vec3 camera_up_vector   = glm::vec3(0.0f,1.0f,0.0f);

float* transform_matrix(MyMate* pvm);
float* wdivision(float* transformed);
float* cullit (float* wdivided);
void show_fps(GLFWwindow* window);

MyObj *obj_model = new MyObj();
int goodTris=0;

int close2gl = 1;
int cw = 1;
int lookat = 1;
int poly_mode = 1;
float near_plane = 0.1f;
float far_plane = 3000.0f;
glm::vec3 model_color = glm::vec3(128/256.0, 128/256.0, 128/256.0);
int shading_index = 0;
int frigging_index = 0;
float vfov = 45.0f;
float hfov = 45.0f;

int translate = 1;  //0:rotate 1:translate
int axis = 1; //1:x 2:y 3:z

float delta = 3.141592 / 16;
float inc;


int main(int argc, char* argv[])
{
    glfwInit();

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window;
    window = glfwCreateWindow(800, 600, "Assignment1", NULL, NULL);

    glfwSetKeyCallback(window, KeyCallback);
    glfwSetMouseButtonCallback(window, MouseButtonCallback);
    glfwSetCursorPosCallback(window, CursorPosCallback);
    glfwSetScrollCallback(window, ScrollCallback);

    glfwMakeContextCurrent(window);

    gladLoadGLLoader((GLADloadproc) glfwGetProcAddress);


    glfwSetFramebufferSizeCallback(window, FramebufferSizeCallback);
    FramebufferSizeCallback(window, 800, 600);


    LoadShadersFromFiles();


    obj_model->Load(argv[1]);

    /*obj_center = obj_model->bbox_middle;
    glm::vec3 z_dist = obj_model->bbox_max - obj_center;
    g_CameraDistance = z_dist.length()*2.0f;
    initial_cam_pos = glm::vec3(obj_center.x, obj_center.y, g_CameraDistance);*/

    //float z_dist = obj_model->bbox_max - obj_center;
    obj_center = obj_model->bbox_middle;
    g_CameraDistance = 3*std::max((obj_model->bbox_max.x - obj_model->bbox_min.x)*(1.0f/tan(45.0)),
                          (obj_model->bbox_max.y - obj_model->bbox_min.y)*(1.0f/tan(1.0*45.0)));

   initial_cam_pos = glm::vec3(obj_center.x, obj_center.y, g_CameraDistance);

    camera_position_c = initial_cam_pos;

    camera_lookat_l = MyMate::normalize(obj_center - camera_position_c);

    inc = 0.005f * g_CameraDistance;

   //VAO CLOSEEEE

    GLuint VBO_close;
    glGenBuffers(1, &VBO_close);

    GLuint VAO_close;
    glGenVertexArrays(1, &VAO_close);


    glBindVertexArray(VAO_close);

    glBindBuffer(GL_ARRAY_BUFFER, VBO_close);

    glBufferData(GL_ARRAY_BUFFER, obj_model->NumTris * 9 * sizeof(float), obj_model->Vert, GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);



    glUseProgram(program_open_id);
    //VAO OPENNN
     GLuint VBO_open;
    glGenBuffers(1, &VBO_open);

    GLuint VAO_open;
    glGenVertexArrays(1, &VAO_open);


    glBindVertexArray(VAO_open);

    glBindBuffer(GL_ARRAY_BUFFER, VBO_open);

    glBufferData(GL_ARRAY_BUFFER, obj_model->NumTris * 9 * sizeof(float), obj_model->Vert, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);



    GLuint VBO_normal_coefficients_id;

    glGenBuffers(1, &VBO_normal_coefficients_id);

    glBindBuffer(GL_ARRAY_BUFFER, VBO_normal_coefficients_id);

    glBufferData(GL_ARRAY_BUFFER, obj_model->NumTris * 9  * sizeof(float), obj_model->Vert_Normal, GL_STATIC_DRAW);

    //glBufferSubData(GL_ARRAY_BUFFER, 0, obj_model->NumTris * 9  * sizeof(float), obj_model->Vert_Normal);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);

    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);





    glBindVertexArray(0);
    glUseProgram(0);




    //imgui setup
    GLFWwindow* gui_window = glfwCreateWindow(363, 580, "ImGui GLFW+OpenGL3 example", NULL, NULL);
    glfwMakeContextCurrent(gui_window);
    glfwSwapInterval(1); // Enable vsync

    // Setup ImGui binding
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    ImGui_ImplGlfwGL3_Init(gui_window, true);

    // Setup style
    ImGui::StyleColorsDark();


    ImVec4 clear_color = ImVec4(0.6f, 0.3f, 0.6f, 1.00f);


    glfwMakeContextCurrent(window);


    while (!glfwWindowShouldClose(window) && !glfwWindowShouldClose(gui_window))
    {

        if(poly_mode==1) glPolygonMode( GL_FRONT_AND_BACK, GL_FILL ); else if(poly_mode==2)
            glPolygonMode( GL_FRONT_AND_BACK, GL_LINE); else glPolygonMode( GL_FRONT_AND_BACK, GL_POINT );


        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



        //glUseProgram(program_close_id);

        glm::mat4 view;
        MyMate* my_view = new MyMate();

        if(lookat){
            /*float r = g_CameraDistance;

            float y = r*sin(g_CameraPhi);
            float z = r*cos(g_CameraPhi)*cos(g_CameraTheta);
            float x = r*cos(g_CameraPhi)*sin(g_CameraTheta);

            camera_position_c  = glm::vec3(x,y,z) + obj_center;*/

            view = glm::lookAt(camera_position_c, obj_center, camera_up_vector);
            my_view->view_matrix(camera_position_c, obj_center-camera_position_c, camera_up_vector);


            /*view =  //glm::rotate(view, g_AngleX*0.5f, glm::vec3(1.0f, 0.0f,0.0f))*
                //glm::rotate(view, g_AngleY*0.5f, glm::vec3(0.0f, 1.0f,0.0f))*
                glm::rotate(view, g_AngleZ, obj_center-camera_position_c);

            my_view->matrix_rotate(MyMate::normalize(obj_center-camera_position_c), g_AngleZ);*/
        }else{
            /*camera_lookat_l.y = 0.5f*sin(g_CameraPhi);
            camera_lookat_l.x = 0.5f*cos(g_CameraPhi)*cos(g_CameraTheta);
            camera_lookat_l.z = 0.5f*cos(g_CameraPhi)*sin(g_CameraTheta);
            camera_lookat_l = glm::normalize(camera_lookat_l);*/

            /*MyMate* rodrigues = new MyMate();
            rodrigues->rotation_matrix(camera_lookat_l, g_AngleZ);

            glm::vec4 camera_up_vector4 = rodrigues->mult(glm::vec4(camera_up_vector, 0.0f));

            camera_up_vector = glm::vec3(camera_up_vector4.x,camera_up_vector4.y,camera_up_vector4.z);*/


            view = glm::lookAt(camera_position_c, camera_position_c + camera_lookat_l, camera_up_vector);
            my_view->view_matrix(camera_position_c, camera_lookat_l, camera_up_vector);

            //view =  //glm::rotate(view, g_AngleX*0.5f, glm::vec3(1.0f, 0.0f,0.0f))*
                //glm::rotate(view, g_AngleY*0.5f, glm::vec3(0.0f, 1.0f,0.0f))*
              //  glm::rotate(view, g_AngleZ, camera_lookat_l);

            //my_view->matrix_rotate(camera_lookat_l, g_AngleZ);
        }

        /*my_view->print();
        std::cout <<  "\n";
        MyMate::printmat4(view);
        return 54;*/


        glm::mat4 projection;
        MyMate* my_projection = new MyMate();

        g_ScreenRatio = tan(glm::radians(hfov / 2)) / tan(glm::radians(vfov / 2));

        projection = glm::perspective(glm::radians(vfov), g_ScreenRatio, near_plane, far_plane);
        my_projection->projection_matrix(glm::radians(vfov), g_ScreenRatio, near_plane, far_plane);

        /*my_projection->print();
        std::cout <<  "\n";
        MyMate::printmat4(projection);
        return 54;*/

        glm::mat4 model = glm::mat4(1.0);

        glFrontFace((cw==1)?GL_CW:GL_CCW);

        if(close2gl){

            glDisable(GL_CULL_FACE);

            MyMate* my_model = new MyMate();

            MyMate* pvm = new MyMate();

            pvm->mult(my_projection);
            pvm->mult(my_view);
            pvm->mult(my_model);

            float* transformed = transform_matrix(pvm);
            float* wdivided = wdivision(transformed);
            free(transformed);
            float* culled = cullit(wdivided);
            free(wdivided);

            glUseProgram(program_close_id);

            glUniform3fv(model_color_uniform_close, 1,glm::value_ptr(model_color));

            glBindVertexArray(VAO_close);

            glBindBuffer(GL_ARRAY_BUFFER, VBO_close);

            glBufferSubData(GL_ARRAY_BUFFER,0, goodTris* 6 * sizeof(float), culled);
            free(culled);

            glDrawArrays(GL_TRIANGLES, 0, goodTris * 3);

            glBindBuffer(GL_ARRAY_BUFFER, 0);

            glBindVertexArray(0);
            glUseProgram(0);

        }else{

            glEnable(GL_CULL_FACE);
            glCullFace(GL_BACK);
            glEnable(GL_DEPTH_TEST);

            glUseProgram(program_open_id);

            glUniformSubroutinesuiv(GL_VERTEX_SHADER, 1, vertShades[shading_index]);
            glUniformSubroutinesuiv(GL_FRAGMENT_SHADER, 1, fragShades[frigging_index]);

            glUniformMatrix4fv(view_uniform       , 1 , GL_FALSE , glm::value_ptr(view));
            glUniformMatrix4fv(projection_uniform , 1 , GL_FALSE , glm::value_ptr(projection));

            glUniformMatrix4fv(model_uniform, 1 , GL_FALSE , glm::value_ptr(model));
            glUniform3fv(model_color_uniform_open, 1,glm::value_ptr(model_color));


            glBindVertexArray(VAO_open);

            glDrawArrays(GL_TRIANGLES, 0, obj_model->NumTris * 9);

            glBindVertexArray(0);
            glUseProgram(0);

        }

        /*pvm->print();
        std::cout <<  "\n";
        MyMate::printmat4(projection*view*model);
        return 54;*/





        /*glm::vec4 testo = glm::vec4(obj_model->Vert[9*2+0],obj_model->Vert[9*2+1],obj_model->Vert[9*2+2], 1.0f);
        glm::vec4 test = projection*view*model*testo;
        std::cout<<testo.x<<" "<<testo.y<<" "<<testo.z<<" "<<testo.w<<"\n";
        std::cout<<test.x<<" "<<test.y<<" "<<test.z<<" "<<test.w<<"\n";
        std::cout<<transformed[12*2+0]<<" "<<transformed[12*2+1]<<" "<<transformed[12*2+2]<<" "<<transformed[12*2+3]<<"\n";
        std::cout<<wdivided[6*2+0]<<" "<<wdivided[6*2+1]<<"\n";
        std::cout<<culled[0]<<" "<<culled[1]<<"\n";
        return 45;*/
        /*int k=0;
        for(int i=0; i<goodTris*3*2;i++)
        std::cout<<culled[k++]<<" "<<culled[k++]<<"\n";

        return 45;*/
        /*glUseProgram(program_open_id);
        glUniformMatrix4fv(view_uniform       , 1 , GL_FALSE , glm::value_ptr(view));
        glUniformMatrix4fv(projection_uniform , 1 , GL_FALSE , glm::value_ptr(projection));

        glUniformMatrix4fv(model_uniform, 1 , GL_FALSE , glm::value_ptr(model));
        glUniform3fv(model_color_uniform_open, 1,glm::value_ptr(model_color));*/


        show_fps(window);

        glfwSwapBuffers(window);

        glfwPollEvents();




        glfwMakeContextCurrent(gui_window);
        //omgui test
        ImGui_ImplGlfwGL3_NewFrame();

        // 1. Show a simple window.
        // Tip: if we don't call ImGui::Begin()/ImGui::End() the widgets automatically appears in a window called "Debug".
        {ImGui::Begin("Assignment2");
            //static float f = 0.0f;
            //static int counter = 0;
            //ImGui::Text("Hello, world!");                           // Display some text (you can use a format string too)
            //ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f

            ImGui::Text("Rendering Type:");
            ImGui::RadioButton("Close2GL", &close2gl, 1);
            ImGui::SameLine();
            ImGui::RadioButton("OpenGL", &close2gl, 0);

            ImGui::Text("\nObject Color");
            ImGui::ColorEdit3("", (float*)&model_color); // Edit 3 floats representing a color

            ImGui::Text("\nCamera Type:");
            ImGui::RadioButton("Look At", &lookat, 1);
            ImGui::SameLine();
            ImGui::RadioButton("Free", &lookat, 0);

            ImGui::Text("\nFront Face:");
            ImGui::RadioButton("CCW", &cw, 0);
            ImGui::SameLine();
            ImGui::RadioButton("CW", &cw, 1);

            ImGui::PushItemWidth(100);

            ImGui::Text("\nClipping Planes:");
            ImGui::InputFloat("Near", &near_plane, 1.0f, 1.0f);
            ImGui::SameLine();
            ImGui::InputFloat("Far", &far_plane, 1.0f, 1.0f);

            ImGui::Text("\nField of view:");
            ImGui::InputFloat("Vert.", &vfov, 1.0f, 1.0f);
            ImGui::SameLine();
            ImGui::InputFloat("Hor.", &hfov, 1.0f, 1.0f);

            ImGui::PopItemWidth();

            //ImGui::Checkbox("Demo Window", &show_demo_window);      // Edit bools storing our windows open/close state
            //ImGui::Checkbox("Another Window", &show_another_window);

            //ImGui::SameLine();
            ImGui::Text("\nPolygon Mode:");
            ImGui::RadioButton("Fill", &poly_mode, 1);
            ImGui::SameLine();
            ImGui::RadioButton("Wire", &poly_mode, 2);
            ImGui::SameLine();
            ImGui::RadioButton("Point", &poly_mode, 3);

            ImGui::Text("\nShading Mode:");
            ImGui::RadioButton("None", &shading_index , 0);
            ImGui::SameLine();
            ImGui::RadioButton("GourAD", &shading_index , 1);
            ImGui::SameLine();
            ImGui::RadioButton("GourADS", &shading_index , 2);
            ImGui::SameLine();
            ImGui::RadioButton("Phong", &shading_index , 3);

            frigging_index =  (shading_index==3)? 1:0;

            ImGui::Text("\nMovement:");
            ImGui::RadioButton("Translate", &translate , 1);
            ImGui::SameLine();
            ImGui::RadioButton("Rotate", &translate , 0);

            ImGui::RadioButton("X", &axis , 1);
            ImGui::SameLine();
            ImGui::RadioButton("Y", &axis , 2);
            ImGui::SameLine();
            ImGui::RadioButton("Z", &axis , 3);


            //chama o callback do teclado com space
            if (ImGui::Button("Reset"))                            // Buttons return true when clicked (NB: most widgets return true when edited/activated)
                KeyCallback(window, GLFW_KEY_SPACE, 24, GLFW_PRESS, 0);




            ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        ImGui::End();}


        // Rendering
        int display_w, display_h;
        glfwGetFramebufferSize(gui_window, &display_w, &display_h);
        glViewport(0, 0, display_w, display_h);
        glClearColor(clear_color.x, clear_color.y, clear_color.z, clear_color.w);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui::Render();
        ImGui_ImplGlfwGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(gui_window);

        glfwMakeContextCurrent(window);
    }

    glfwTerminate();

    return 0;
}

float* transform_matrix(MyMate* pvm){
    float* vert = obj_model->Vert;
    int badTris = 0;
    int numtris = obj_model->NumTris;
    goodTris = numtris; //por enquanto todos tris s�o bons
    float* transformed = new float[numtris*12]; //cada tri tem 3 vertices em coord homo

    glm::vec4 v1, v1l, v2, v2l, v3, v3l;

    int i =0;
    //i indexa os triangulos que s�o passados e j itera todos os que s�o transformados
    for(int j=0; j<numtris;j++){
        v1 = glm::vec4(vert[9 * j + 0],vert[9 * j + 1],vert[9 * j + 2],1.0f);
        v2 = glm::vec4(vert[9 * j + 3],vert[9 * j + 4],vert[9 * j + 5],1.0f);
        v3 = glm::vec4(vert[9 * j + 6],vert[9 * j + 7],vert[9 * j + 8],1.0f);

        v1l = pvm->mult(v1);
        v2l = pvm->mult(v2);
        v3l = pvm->mult(v3);

        if((v1l.w <=0)||(v2l.w <=0)||(v3l.w <=0)){
            badTris++;  //aumenta o  n�mero de de triangulos que ser�o descartados
            continue;
        }

        transformed[12 * i + 0] = v1l.x;
        transformed[12 * i + 1] = v1l.y;
        transformed[12 * i + 2] = v1l.z; //n�o precisa de z na real n�? too late
        transformed[12 * i + 3] = v1l.w;
        transformed[12 * i + 4] = v2l.x;
        transformed[12 * i + 5] = v2l.y;
        transformed[12 * i + 6] = v2l.z;
        transformed[12 * i + 7] = v2l.w;
        transformed[12 * i + 8] = v3l.x;
        transformed[12 * i + 9] = v3l.y;
        transformed[12 * i + 10] = v3l.z;
        transformed[12 * i + 11] = v3l.w;
        i++;
    }
    goodTris -= badTris;  //menos tris bons
    float* ret = new float [goodTris*12]; //alocamos mem�rioa no array apenas para os caras bons
    std::memcpy(ret,transformed,goodTris*12*sizeof(float)); //botamos apenas os bons no retorno
    free(transformed);

    return ret;
}

float* wdivision(float* transformed){
    float* wdivided = new float[goodTris*6];

    for(int i=0; i<goodTris;i++){
        wdivided[6 * i + 0] = transformed[12 * i + 0]/transformed[12 * i + 3]; //divide x e y dos transformed
        wdivided[6 * i + 1] = transformed[12 * i + 1]/transformed[12 * i + 3]; // por w dos tranformed
        wdivided[6 * i + 2] = transformed[12 * i + 4]/transformed[12 * i + 7];
        wdivided[6 * i + 3] = transformed[12 * i + 5]/transformed[12 * i + 7];
        wdivided[6 * i + 4] = transformed[12 * i + 8]/transformed[12 * i + 11];
        wdivided[6 * i + 5] = transformed[12 * i + 9]/transformed[12 * i + 11];
    }
    return wdivided;
}

float* cullit (float* wdivided){
    float* culled = new float[goodTris*6];
    int badTris = 0;
    float a=0.0f;

    // i indexa os triangulos que ser�o retornados. j itera todo triangulio que � testado
    if(cw){
        int i =0;
        for(int j=0;j<goodTris;j++){
            a = ((wdivided[6*j+0]*wdivided[6*j+3])-(wdivided[6*j+2]*wdivided[6*j+1]))+
                ((wdivided[6*j+2]*wdivided[6*j+5])-(wdivided[6*j+4]*wdivided[6*j+3]))+
                ((wdivided[6*j+4]*wdivided[6*j+1])-(wdivided[6*j+0]*wdivided[6*j+5]));

            if(a>=0){
                badTris++;  //tri backfacing � ruim e descartado
                continue;
            }
            culled[6 * i + 0] = wdivided[6*j+0];
            culled[6 * i + 1] = wdivided[6*j+1];
            culled[6 * i + 2] = wdivided[6*j+2];
            culled[6 * i + 3] = wdivided[6*j+3];
            culled[6 * i + 4] = wdivided[6*j+4];
            culled[6 * i + 5] = wdivided[6*j+5];
            i++;
        }
    }else{
        int i=0;
        for(int j=0;j<goodTris;j++){
            a = ((wdivided[6*j+0]*wdivided[6*j+3])-(wdivided[6*j+2]*wdivided[6*j+1]))+
                ((wdivided[6*j+2]*wdivided[6*j+5])-(wdivided[6*j+4]*wdivided[6*j+3]))+
                ((wdivided[6*j+4]*wdivided[6*j+1])-(wdivided[6*j+0]*wdivided[6*j+5]));

            if(a<=0){
                badTris++;  //tri backfacing � ruim e descartado
                continue;
            }
            culled[6 * i + 0] = wdivided[6*j+0];
            culled[6 * i + 1] = wdivided[6*j+1];
            culled[6 * i + 2] = wdivided[6*j+2];
            culled[6 * i + 3] = wdivided[6*j+3];
            culled[6 * i + 4] = wdivided[6*j+4];
            culled[6 * i + 5] = wdivided[6*j+5];
            i++;
        }
    }
    goodTris -= badTris;
    float* ret = new float[goodTris*6];
    std::memcpy(ret, culled, goodTris*6*sizeof(float));
    free(culled);

    return ret;
}


void LoadShadersFromFiles()
{
    vertex_shader_close_id = LoadShader_Vertex("../../src/shader_vertex.glsl");
    vertex_shader_open_id = LoadShader_Vertex("../../src/shader_open.glsl");
    fragment_shader_close_id = LoadShader_Fragment("../../src/shader_fragment.glsl");
    fragment_shader_open_id = LoadShader_Fragment("../../src/shader_fopen.glsl");

    program_close_id = CreateGpuProgram(vertex_shader_close_id, fragment_shader_close_id);
    program_open_id = CreateGpuProgram(vertex_shader_open_id, fragment_shader_open_id);


    model_uniform           = glGetUniformLocation(program_open_id, "model");
    view_uniform            = glGetUniformLocation(program_open_id, "view");
    projection_uniform      = glGetUniformLocation(program_open_id, "projection");
    model_color_uniform_open     = glGetUniformLocation(program_open_id, "in_color");
    model_color_uniform_close     = glGetUniformLocation(program_close_id, "in_color");


    vertex_type_uniform = glGetSubroutineUniformLocation(program_open_id, GL_VERTEX_SHADER, "vertex_shading_type");
    no_shade_index = glGetSubroutineIndex(program_open_id, GL_VERTEX_SHADER, "none");
    gourAD_shade_index = glGetSubroutineIndex(program_open_id, GL_VERTEX_SHADER, "gourAD");
    gourADS_shade_index = glGetSubroutineIndex(program_open_id, GL_VERTEX_SHADER, "gourADS");
    phong_shade_index = glGetSubroutineIndex(program_open_id, GL_VERTEX_SHADER, "phong");

    frag_type_uniform = glGetSubroutineUniformLocation(program_open_id, GL_VERTEX_SHADER, "frag_shading_type");
    nonef_index = glGetSubroutineIndex(program_open_id, GL_FRAGMENT_SHADER, "nonef");
    phongf_index = glGetSubroutineIndex(program_open_id, GL_FRAGMENT_SHADER, "phongf");


    glUseProgram(program_open_id);

    glUseProgram(0);
}

GLuint LoadShader_Vertex(const char* filename)
{
    GLuint vertex_shader_id = glCreateShader(GL_VERTEX_SHADER);


    LoadShader(filename, vertex_shader_id);

    return vertex_shader_id;
}

GLuint LoadShader_Fragment(const char* filename)
{

    GLuint fragment_shader_id = glCreateShader(GL_FRAGMENT_SHADER);

    LoadShader(filename, fragment_shader_id);

    return fragment_shader_id;
}


void LoadShader(const char* filename, GLuint shader_id)
{
    std::ifstream file;
    try {
        file.exceptions(std::ifstream::failbit);
        file.open(filename);
    } catch ( std::exception& e ) {
        fprintf(stderr, "ERROR: Cannot open file \"%s\".\n", filename);
        std::exit(EXIT_FAILURE);
    }
    std::stringstream shader;
    shader << file.rdbuf();
    std::string str = shader.str();
    const GLchar* shader_string = str.c_str();
    const GLint   shader_string_length = static_cast<GLint>( str.length() );

    glShaderSource(shader_id, 1, &shader_string, &shader_string_length);

    glCompileShader(shader_id);

    GLint compiled_ok;
    glGetShaderiv(shader_id, GL_COMPILE_STATUS, &compiled_ok);

    GLint log_length = 0;
    glGetShaderiv(shader_id, GL_INFO_LOG_LENGTH, &log_length);

    GLchar* log = new GLchar[log_length];
    glGetShaderInfoLog(shader_id, log_length, &log_length, log);

    if ( log_length != 0 )
	{
        std::string  output;

		if ( !compiled_ok )
		{
			output += "ERROR: OpenGL compilation of \"";
			output += filename;
			output += "\" failed.\n";
			output += "== Start of compilation log\n";
			output += log;
			output += "== End of compilation log\n";
		}
		else
		{
			output += "WARNING: OpenGL compilation of \"";
			output += filename;
			output += "\".\n";
			output += "== Start of compilation log\n";
			output += log;
			output += "== End of compilation log\n";
		}

        fprintf(stderr, "%s", output.c_str());
	}


    delete [] log;
}

GLuint CreateGpuProgram(GLuint vertex_shader_id, GLuint fragment_shader_id)
{
    GLuint program_id = glCreateProgram();

    glAttachShader(program_id, vertex_shader_id);
    glAttachShader(program_id, fragment_shader_id);


    glLinkProgram(program_id);


    GLint linked_ok = GL_FALSE;
    glGetProgramiv(program_id, GL_LINK_STATUS, &linked_ok);

    if ( linked_ok == GL_FALSE )
    {
        GLint log_length = 0;
        glGetProgramiv(program_id, GL_INFO_LOG_LENGTH, &log_length);


        GLchar* log = new GLchar[log_length];

        glGetProgramInfoLog(program_id, log_length, &log_length, log);

        std::string output;

        output += "ERROR: OpenGL linking of program failed.\n";
        output += "== Start of link log\n";
        output += log;
        output += "\n== End of link log\n";

        delete [] log;

        fprintf(stderr, "%s", output.c_str());
    }

    glDeleteShader(vertex_shader_id);
    glDeleteShader(fragment_shader_id);

    return program_id;
}

void FramebufferSizeCallback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);

    g_ScreenRatio = (float)width / height;
}

double g_LastCursorPosX, g_LastCursorPosY;

void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
    {
        glfwGetCursorPos(window, &g_LastCursorPosX, &g_LastCursorPosY);
        g_LeftMouseButtonPressed = true;
    }
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_RELEASE)
    {
        g_LeftMouseButtonPressed = false;
    }
    if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
    {
        glfwGetCursorPos(window, &g_LastCursorPosX, &g_LastCursorPosY);
        g_RightMouseButtonPressed = true;
    }
    if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_RELEASE)
    {
        g_RightMouseButtonPressed = false;
    }
    if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_PRESS)
    {
        glfwGetCursorPos(window, &g_LastCursorPosX, &g_LastCursorPosY);
        g_MiddleMouseButtonPressed = true;
    }
    if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_RELEASE)
    {
        g_MiddleMouseButtonPressed = false;
    }
}

void CursorPosCallback(GLFWwindow* window, double xpos, double ypos)
{

    if (g_LeftMouseButtonPressed)
    {
        float dx = xpos - g_LastCursorPosX;
        float dy = ypos - g_LastCursorPosY;

        g_CameraTheta -= 0.01f*dx;
        g_CameraPhi   += 0.01f*dy;


        /*if (key == GLFW_KEY_X && action == GLFW_PRESS)
        {
            g_AngleX += (mod & GLFW_MOD_SHIFT) ? -delta : delta;
        }

        if (key == GLFW_KEY_Y && action == GLFW_PRESS)
        {
            g_AngleY += (mod & GLFW_MOD_SHIFT) ? -delta : delta;
        }*/

        if (!lookat){
            if(!translate){
                if (axis==3)
                {
                    MyMate* rodrigues = new MyMate();
                    rodrigues->rotation_matrix(camera_lookat_l, delta*dx*inc*0.005f);

                    glm::vec4 camera_up_vector4 = rodrigues->mult(glm::vec4(camera_up_vector, 0.0f));

                    camera_up_vector = MyMate::normalize(glm::vec3(camera_up_vector4.x,camera_up_vector4.y,camera_up_vector4.z));
                    //g_AngleZ +=  delta*dx;
                }
                if (axis==2)
                {
                    MyMate* rodrigues = new MyMate();
                    rodrigues->rotation_matrix(camera_up_vector, delta*dx*inc*0.005f);

                    glm::vec4 camera_lookat_l4 = rodrigues->mult(glm::vec4(camera_lookat_l, 0.0f));

                    camera_lookat_l = MyMate::normalize(glm::vec3(camera_lookat_l4.x,camera_lookat_l4.y,camera_lookat_l4.z));
                    //g_AngleZ +=  delta*dx;
                }
                if (axis==1)
                {
                    MyMate* rodrigues = new MyMate();
                    rodrigues->rotation_matrix(MyMate::crossproduct(camera_up_vector,camera_lookat_l), delta*dy*inc*0.005f);

                    glm::vec4 camera_lookat_l4 = rodrigues->mult(glm::vec4(camera_lookat_l, 0.0f));

                    camera_lookat_l = MyMate::normalize(glm::vec3(camera_lookat_l4.x,camera_lookat_l4.y,camera_lookat_l4.z));
                    //g_AngleZ +=  delta*dx;
                }
            }
            if(translate){
                if(axis==1){
                    camera_position_c += inc *dx* glm::cross(camera_lookat_l,camera_up_vector);
                }
                if(axis==2){
                    camera_position_c += inc*dy* camera_up_vector;
                }
                if(axis==3){
                    camera_position_c += inc*dy* camera_lookat_l;
                }

            }
        }
        else{
            if(translate){
                if(axis==1){
                    camera_position_c += inc *dx* MyMate::normalize(glm::cross(camera_lookat_l,camera_up_vector));
                }
                if(axis==2){
                    camera_position_c += inc*dy* camera_up_vector;
                }
                if(axis==3){
                    camera_position_c += inc*dy* camera_lookat_l;
                }
                camera_lookat_l = MyMate::normalize(obj_center - camera_position_c);
                camera_up_vector = -glm::normalize(glm::cross(camera_lookat_l, glm::cross(camera_lookat_l,camera_up_vector)));
                //camera_position_c = g_CameraDistance * MyMate::normalize(camera_position_c);

            }
        }



        float phimax = 3.141592f/2;
        float phimin = -phimax;

        if (g_CameraPhi > phimax)
            g_CameraPhi = phimax;

        if (g_CameraPhi < phimin)
            g_CameraPhi = phimin;

        g_LastCursorPosX = xpos;
        g_LastCursorPosY = ypos;
    }

    if (g_RightMouseButtonPressed)
    {
        float dx = xpos - g_LastCursorPosX;
        float dy = ypos - g_LastCursorPosY;

        g_LastCursorPosX = xpos;
        g_LastCursorPosY = ypos;
    }

    if (g_MiddleMouseButtonPressed)
    {
        float dx = xpos - g_LastCursorPosX;
        float dy = ypos - g_LastCursorPosY;


        g_LastCursorPosX = xpos;
        g_LastCursorPosY = ypos;
    }
}


void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mod)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);

    float delta = 3.141592 / 16;

    if (key == GLFW_KEY_X && action == GLFW_PRESS)
    {
        g_AngleX += (mod & GLFW_MOD_SHIFT) ? -delta : delta;
    }

    if (key == GLFW_KEY_Y && action == GLFW_PRESS)
    {
        g_AngleY += (mod & GLFW_MOD_SHIFT) ? -delta : delta;
    }
    if (key == GLFW_KEY_Z && action == GLFW_PRESS)
    {
        g_AngleZ += (mod & GLFW_MOD_SHIFT) ? -delta : delta;
    }

    if (key == GLFW_KEY_W)
    {
        float inc = 0.05f;
        camera_position_c += inc* camera_lookat_l;
    }
    if (key == GLFW_KEY_S)
    {
        float inc = 0.05f;
        camera_position_c -= inc* camera_lookat_l;
    }
    if (key == GLFW_KEY_A)
    {
        float inc = 0.05f;
        camera_position_c -= inc* glm::cross(camera_lookat_l,camera_up_vector);
    }
    if (key == GLFW_KEY_D)
    {
        float inc = 0.05f;
        camera_position_c += inc* glm::cross(camera_lookat_l,camera_up_vector);
    }

    if (key == GLFW_KEY_E)
    {
        float inc = 0.05f;
        camera_position_c += inc* camera_up_vector;
    }

    if (key == GLFW_KEY_Q)
    {
        float inc = 0.05f;
        camera_position_c -= inc* camera_up_vector;
    }


    if (key == GLFW_KEY_1 && action == GLFW_PRESS){
        poly_mode = 1;
    }
    if (key == GLFW_KEY_3 && action == GLFW_PRESS){
        poly_mode = 3;
    }
    if (key == GLFW_KEY_2 && action == GLFW_PRESS){
        poly_mode = 2;
    }

    if (key == GLFW_KEY_4 && action == GLFW_PRESS){
        shading_index= 0;
        frigging_index = 0;
    }
    if (key == GLFW_KEY_5 && action == GLFW_PRESS){
        shading_index= 1;
        frigging_index = 0;
    }
    if (key == GLFW_KEY_6 && action == GLFW_PRESS){
        shading_index= 2;
        frigging_index = 0;
    }
    if (key == GLFW_KEY_7 && action == GLFW_PRESS){
       shading_index= 3;
       frigging_index = 1;
    }


    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
    {
        camera_position_c = initial_cam_pos;
        g_CameraDistance = initial_cam_pos.z;

        camera_up_vector = glm::vec3(0.0f, 1.0f, 0.0f);
        camera_lookat_l = glm::normalize(obj_center - camera_position_c);
    }


    if (key == GLFW_KEY_0 && action == GLFW_PRESS)
    {
        LoadShadersFromFiles();
        fprintf(stdout,"Shaders recarregados!\n");
        fflush(stdout);
    }

    if (key == GLFW_KEY_R && action == GLFW_PRESS){
        int r, g, b;

        std::cout << "\nInsira valor de red:\n";
        std::cin >> r;
        std::cout << "Insira valor de green:\n";
        std::cin >> g;
        std::cout << "Insira valor de blue:\n";
        std::cin >> b;
        std::cout << "Soh valeu!\n";

        model_color = glm::vec3(r/256.0, g/256.0, b/256.0);
    }

     if (key == GLFW_KEY_P && action == GLFW_PRESS){

        std::cout << "\nInsira valor de near plane:\n";
        std::cin >> near_plane;
        std::cout << "Insira valor de far plane:\n";
        std::cin >> far_plane;
        std::cout << "Soh valeu!\n";

    }

    if (key == GLFW_KEY_L && action == GLFW_PRESS){
        if(lookat){
            //camera_position_c = initial_cam_pos;
            //camera_position_c.z /= 2.5f;

                    camera_position_c = initial_cam_pos;
                    g_CameraDistance = initial_cam_pos.z;
            g_AngleX = 0.0f;
            g_AngleY = 0.0f;
            g_AngleZ = 0.0f;
            //g_CameraTheta = 0.0f;
            g_CameraPhi = 0.0f;



            lookat=0;
            //camera_lookat_l    = glm::vec3(0.0f,0.0f,-1.0f);
            camera_lookat_l =  obj_center - camera_position_c;
            camera_lookat_l = glm::normalize(camera_lookat_l);
            glm::vec3 proj = glm::vec3(camera_lookat_l.x,0.0f,camera_lookat_l.z);

            float cosa = dot(glm::vec3(1.0f,0.0f,0.0f), proj);
            g_CameraTheta = (proj.z <=0)? -acos(cosa): acos(cosa);
        }
        else{
            camera_position_c = initial_cam_pos;
            g_CameraDistance = initial_cam_pos.z;
            g_AngleX = 0.0f;
            g_AngleY = 0.0f;
            g_AngleZ = 0.0f;
            g_CameraTheta = 0.0f;
            g_CameraPhi = 0.0f;


            lookat=1;
        }


    }

    if (key == GLFW_KEY_C && action == GLFW_PRESS){
            if(cw){
                cw=0;
                glFrontFace(GL_CCW);
            }else{
                cw=1;
                glFrontFace(GL_CW);
            }
    }

    if (key == GLFW_KEY_O && action == GLFW_PRESS) {
            if(close2gl){
                close2gl=0;
                glEnable(GL_CULL_FACE);
                glCullFace(GL_BACK);
                glEnable(GL_DEPTH_TEST);
            }else{
                close2gl=1;
                glDisable(GL_CULL_FACE);
            }
    }
}

void ScrollCallback(GLFWwindow* window, double xoffset, double yoffset){
    g_CameraDistance -= 0.9f*yoffset;

    if (g_CameraDistance < 0.0f)
        g_CameraDistance = 0.0f;
}

void show_fps(GLFWwindow* window){

    static float old_seconds = (float)glfwGetTime();
    static int   ellapsed_frames = 0;
    static char  buffer[20] = "?? fps";
    static int   numchars = 7;

    ellapsed_frames += 1;

    // Recuperamos o n�mero de segundos que passou desde a execu��o do programa
    float seconds = (float)glfwGetTime();

    // N�mero de segundos desde o �ltimo c�lculo do fps
    float ellapsed_seconds = seconds - old_seconds;

    if ( ellapsed_seconds > 1.0f )
    {
        numchars = snprintf(buffer, 20, "%.2f fps", ellapsed_frames / ellapsed_seconds);

        old_seconds = seconds;
        ellapsed_frames = 0;
    }
    glfwSetWindowTitle(window, buffer);
}
